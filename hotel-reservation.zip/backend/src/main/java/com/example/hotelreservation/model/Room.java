package com.example.hotelreservation.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="rooms")
public class Room {
@Id private String id;
private String roomId;
private String roomType;
private double pricePerNight;
private int capacity;
private boolean available;
public Room(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getRoomId(){return roomId;} public void setRoomId(String roomId){this.roomId=roomId;}
public String getRoomType(){return roomType;} public void setRoomType(String roomType){this.roomType=roomType;}
public double getPricePerNight(){return pricePerNight;} public void setPricePerNight(double pricePerNight){this.pricePerNight=pricePerNight;}
public int getCapacity(){return capacity;} public void setCapacity(int capacity){this.capacity=capacity;}
public boolean getAvailable(){return available;} public void setAvailable(boolean available){this.available=available;}
}
