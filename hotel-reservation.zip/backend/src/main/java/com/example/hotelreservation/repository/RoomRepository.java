package com.example.hotelreservation.repository;
import com.example.hotelreservation.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RoomRepository extends MongoRepository<Room,String>{}
