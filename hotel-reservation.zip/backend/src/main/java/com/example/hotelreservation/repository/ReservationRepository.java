package com.example.hotelreservation.repository;
import com.example.hotelreservation.model.Reservation;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ReservationRepository extends MongoRepository<Reservation,String>{}
