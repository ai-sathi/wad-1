package com.example.courseregistration.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="courses")
public class Course {
@Id private String id;
private String courseId;
private String courseName;
private String instructor;
private int capacity;
private double fee;
public Course(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getCourseId(){return courseId;} public void setCourseId(String courseId){this.courseId=courseId;}
public String getCourseName(){return courseName;} public void setCourseName(String courseName){this.courseName=courseName;}
public String getInstructor(){return instructor;} public void setInstructor(String instructor){this.instructor=instructor;}
public int getCapacity(){return capacity;} public void setCapacity(int capacity){this.capacity=capacity;}
public double getFee(){return fee;} public void setFee(double fee){this.fee=fee;}
}
