package com.example.libraryissues.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="issues")
public class Issue {
@Id private String id;
private String issueId;
private String studentName;
private String bookId;
private String issueDate;
private String dueDate;
private String status;
public Issue(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getIssueId(){return issueId;} public void setIssueId(String issueId){this.issueId=issueId;}
public String getStudentName(){return studentName;} public void setStudentName(String studentName){this.studentName=studentName;}
public String getBookId(){return bookId;} public void setBookId(String bookId){this.bookId=bookId;}
public String getIssueDate(){return issueDate;} public void setIssueDate(String issueDate){this.issueDate=issueDate;}
public String getDueDate(){return dueDate;} public void setDueDate(String dueDate){this.dueDate=dueDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
