package com.example.libraryissues.controller;
import com.example.libraryissues.model.Book; import com.example.libraryissues.repository.BookRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/books") @CrossOrigin(origins="http://localhost:5173")
public class BookController {
private final BookRepository repo; public BookController(BookRepository repo){this.repo=repo;}
@GetMapping public List<Book> all(){return repo.findAll();}
@GetMapping("/{id}") public Book one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Book create(@RequestBody Book x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Book update(@PathVariable String id,@RequestBody Book x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
