package com.example.libraryissues.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="books")
public class Book {
@Id private String id;
private String bookId;
private String title;
private String author;
private int copiesAvailable;
private String category;
public Book(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getBookId(){return bookId;} public void setBookId(String bookId){this.bookId=bookId;}
public String getTitle(){return title;} public void setTitle(String title){this.title=title;}
public String getAuthor(){return author;} public void setAuthor(String author){this.author=author;}
public int getCopiesAvailable(){return copiesAvailable;} public void setCopiesAvailable(int copiesAvailable){this.copiesAvailable=copiesAvailable;}
public String getCategory(){return category;} public void setCategory(String category){this.category=category;}
}
