package com.example.couriertracking.controller;
import com.example.couriertracking.model.Shipment; import com.example.couriertracking.repository.ShipmentRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/shipments") @CrossOrigin(origins="http://localhost:5173")
public class ShipmentController {
private final ShipmentRepository repo; public ShipmentController(ShipmentRepository repo){this.repo=repo;}
@GetMapping public List<Shipment> all(){return repo.findAll();}
@GetMapping("/{id}") public Shipment one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Shipment create(@RequestBody Shipment x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Shipment update(@PathVariable String id,@RequestBody Shipment x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
