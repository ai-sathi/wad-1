package com.example.couriertracking.repository;
import com.example.couriertracking.model.DeliveryAgent;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DeliveryAgentRepository extends MongoRepository<DeliveryAgent,String>{}
