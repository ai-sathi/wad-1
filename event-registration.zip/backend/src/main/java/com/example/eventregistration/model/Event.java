package com.example.eventregistration.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="events")
public class Event {
@Id private String id;
private String eventId;
private String name;
private String venue;
private String eventDate;
private int capacity;
public Event(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getEventId(){return eventId;} public void setEventId(String eventId){this.eventId=eventId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getVenue(){return venue;} public void setVenue(String venue){this.venue=venue;}
public String getEventDate(){return eventDate;} public void setEventDate(String eventDate){this.eventDate=eventDate;}
public int getCapacity(){return capacity;} public void setCapacity(int capacity){this.capacity=capacity;}
}
