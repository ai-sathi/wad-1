package com.example.eventregistration.repository;
import com.example.eventregistration.model.EventRegistration;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface EventRegistrationRepository extends MongoRepository<EventRegistration,String>{}
