package com.example.onlineshopping.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="products")
public class Product {
@Id private String id;
private String productId;
private String name;
private String category;
private double price;
private int stock;
public Product(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getProductId(){return productId;} public void setProductId(String productId){this.productId=productId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getCategory(){return category;} public void setCategory(String category){this.category=category;}
public double getPrice(){return price;} public void setPrice(double price){this.price=price;}
public int getStock(){return stock;} public void setStock(int stock){this.stock=stock;}
}
