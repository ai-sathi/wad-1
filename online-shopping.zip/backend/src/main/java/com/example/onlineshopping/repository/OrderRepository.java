package com.example.onlineshopping.repository;
import com.example.onlineshopping.model.Order;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface OrderRepository extends MongoRepository<Order,String>{}
