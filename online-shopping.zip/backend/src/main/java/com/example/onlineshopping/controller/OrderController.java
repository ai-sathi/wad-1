package com.example.onlineshopping.controller;
import com.example.onlineshopping.model.Order; import com.example.onlineshopping.repository.OrderRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/orders") @CrossOrigin(origins="http://localhost:5173")
public class OrderController {
private final OrderRepository repo; public OrderController(OrderRepository repo){this.repo=repo;}
@GetMapping public List<Order> all(){return repo.findAll();}
@GetMapping("/{id}") public Order one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Order create(@RequestBody Order x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Order update(@PathVariable String id,@RequestBody Order x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
