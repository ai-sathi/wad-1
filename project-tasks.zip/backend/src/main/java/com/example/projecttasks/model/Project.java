package com.example.projecttasks.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="projects")
public class Project {
@Id private String id;
private String projectId;
private String name;
private String manager;
private String startDate;
private String status;
public Project(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getProjectId(){return projectId;} public void setProjectId(String projectId){this.projectId=projectId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getManager(){return manager;} public void setManager(String manager){this.manager=manager;}
public String getStartDate(){return startDate;} public void setStartDate(String startDate){this.startDate=startDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
