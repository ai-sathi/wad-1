package com.example.projecttasks.controller;
import com.example.projecttasks.model.Task; import com.example.projecttasks.repository.TaskRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/tasks") @CrossOrigin(origins="http://localhost:5173")
public class TaskController {
private final TaskRepository repo; public TaskController(TaskRepository repo){this.repo=repo;}
@GetMapping public List<Task> all(){return repo.findAll();}
@GetMapping("/{id}") public Task one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Task create(@RequestBody Task x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Task update(@PathVariable String id,@RequestBody Task x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
