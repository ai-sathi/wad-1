package com.example.projecttasks.repository;
import com.example.projecttasks.model.Project;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ProjectRepository extends MongoRepository<Project,String>{}
