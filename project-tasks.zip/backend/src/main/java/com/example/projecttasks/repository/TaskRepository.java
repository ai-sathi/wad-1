package com.example.projecttasks.repository;
import com.example.projecttasks.model.Task;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface TaskRepository extends MongoRepository<Task,String>{}
