package com.example.collegeplacement.repository;
import com.example.collegeplacement.model.Placement;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PlacementRepository extends MongoRepository<Placement,String>{}
