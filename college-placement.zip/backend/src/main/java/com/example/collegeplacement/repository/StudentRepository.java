package com.example.collegeplacement.repository;
import com.example.collegeplacement.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface StudentRepository extends MongoRepository<Student,String>{}
