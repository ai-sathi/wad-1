package com.example.collegeplacement.controller;
import com.example.collegeplacement.model.Student; import com.example.collegeplacement.repository.StudentRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/students") @CrossOrigin(origins="http://localhost:5173")
public class StudentController {
private final StudentRepository repo; public StudentController(StudentRepository repo){this.repo=repo;}
@GetMapping public List<Student> all(){return repo.findAll();}
@GetMapping("/{id}") public Student one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Student create(@RequestBody Student x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Student update(@PathVariable String id,@RequestBody Student x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
