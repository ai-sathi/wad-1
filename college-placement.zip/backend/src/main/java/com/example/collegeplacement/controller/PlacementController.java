package com.example.collegeplacement.controller;
import com.example.collegeplacement.model.Placement; import com.example.collegeplacement.repository.PlacementRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/placements") @CrossOrigin(origins="http://localhost:5173")
public class PlacementController {
private final PlacementRepository repo; public PlacementController(PlacementRepository repo){this.repo=repo;}
@GetMapping public List<Placement> all(){return repo.findAll();}
@GetMapping("/{id}") public Placement one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Placement create(@RequestBody Placement x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Placement update(@PathVariable String id,@RequestBody Placement x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
