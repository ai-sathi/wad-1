package com.example.collegeplacement.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="placements")
public class Placement {
@Id private String id;
private String placementId;
private String studentId;
private String companyName;
private String role;
private double packageLpa;
private String status;
public Placement(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getPlacementId(){return placementId;} public void setPlacementId(String placementId){this.placementId=placementId;}
public String getStudentId(){return studentId;} public void setStudentId(String studentId){this.studentId=studentId;}
public String getCompanyName(){return companyName;} public void setCompanyName(String companyName){this.companyName=companyName;}
public String getRole(){return role;} public void setRole(String role){this.role=role;}
public double getPackageLpa(){return packageLpa;} public void setPackageLpa(double packageLpa){this.packageLpa=packageLpa;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
