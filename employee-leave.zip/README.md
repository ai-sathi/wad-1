# Employee Leave Management — Lab Exam Practice

Java 17 target · Spring Boot 3.3.5 · MongoDB · Vue 3 · Axios

## Included logic
- CRUD for `employees` and `leaves` (create, list, find by ID, update, delete)
- Form-based Vue UI with field inputs, records table, edit and delete actions
- Scenario-specific report: **Pending leave requests** (`status equals PENDING`)
- MongoDB aggregation join using `$lookup`: `leaves.employeeId` matched to `employees.employeeId`

## Run
1. Start MongoDB locally (`mongodb://localhost:27017`).
2. In `backend`, run `mvn spring-boot:run`.
3. In a second terminal, enter `frontend`, run `npm install` and `npm run dev`.
4. Open the Vite URL, normally `http://localhost:5173`.

## API
- GET/POST `/api/employees`
- GET/PUT/DELETE `/api/employees/{id}`
- GET/POST `/api/leaves`
- GET/PUT/DELETE `/api/leaves/{id}`
- GET `/api/reports/special`
- GET `/api/reports/joined`

The relationship field `employeeId` must have the same value in both collections for the join to match. This is a lab practice project; adjust rules to the exact question statement.
