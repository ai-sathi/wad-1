package com.example.employeeleave.controller;
import com.example.employeeleave.model.Employee; import com.example.employeeleave.repository.EmployeeRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/employees") @CrossOrigin(origins="http://localhost:5173")
public class EmployeeController {
private final EmployeeRepository repo; public EmployeeController(EmployeeRepository repo){this.repo=repo;}
@GetMapping public List<Employee> all(){return repo.findAll();}
@GetMapping("/{id}") public Employee one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Employee create(@RequestBody Employee x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Employee update(@PathVariable String id,@RequestBody Employee x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
