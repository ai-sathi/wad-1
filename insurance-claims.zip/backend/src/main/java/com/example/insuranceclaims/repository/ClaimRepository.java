package com.example.insuranceclaims.repository;
import com.example.insuranceclaims.model.Claim;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ClaimRepository extends MongoRepository<Claim,String>{}
