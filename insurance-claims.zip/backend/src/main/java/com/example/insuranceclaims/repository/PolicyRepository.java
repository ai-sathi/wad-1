package com.example.insuranceclaims.repository;
import com.example.insuranceclaims.model.Policy;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PolicyRepository extends MongoRepository<Policy,String>{}
