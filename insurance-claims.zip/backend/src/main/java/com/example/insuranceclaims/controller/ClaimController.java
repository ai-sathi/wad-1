package com.example.insuranceclaims.controller;
import com.example.insuranceclaims.model.Claim; import com.example.insuranceclaims.repository.ClaimRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/claims") @CrossOrigin(origins="http://localhost:5173")
public class ClaimController {
private final ClaimRepository repo; public ClaimController(ClaimRepository repo){this.repo=repo;}
@GetMapping public List<Claim> all(){return repo.findAll();}
@GetMapping("/{id}") public Claim one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Claim create(@RequestBody Claim x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Claim update(@PathVariable String id,@RequestBody Claim x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
