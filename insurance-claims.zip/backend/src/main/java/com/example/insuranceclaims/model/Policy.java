package com.example.insuranceclaims.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="policies")
public class Policy {
@Id private String id;
private String policyId;
private String holderName;
private String policyType;
private double premium;
private double coverageAmount;
public Policy(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getPolicyId(){return policyId;} public void setPolicyId(String policyId){this.policyId=policyId;}
public String getHolderName(){return holderName;} public void setHolderName(String holderName){this.holderName=holderName;}
public String getPolicyType(){return policyType;} public void setPolicyType(String policyType){this.policyType=policyType;}
public double getPremium(){return premium;} public void setPremium(double premium){this.premium=premium;}
public double getCoverageAmount(){return coverageAmount;} public void setCoverageAmount(double coverageAmount){this.coverageAmount=coverageAmount;}
}
