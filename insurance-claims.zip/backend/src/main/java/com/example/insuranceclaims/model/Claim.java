package com.example.insuranceclaims.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="claims")
public class Claim {
@Id private String id;
private String claimId;
private String policyId;
private String claimantName;
private double claimAmount;
private String claimDate;
private String status;
public Claim(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getClaimId(){return claimId;} public void setClaimId(String claimId){this.claimId=claimId;}
public String getPolicyId(){return policyId;} public void setPolicyId(String policyId){this.policyId=policyId;}
public String getClaimantName(){return claimantName;} public void setClaimantName(String claimantName){this.claimantName=claimantName;}
public double getClaimAmount(){return claimAmount;} public void setClaimAmount(double claimAmount){this.claimAmount=claimAmount;}
public String getClaimDate(){return claimDate;} public void setClaimDate(String claimDate){this.claimDate=claimDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
