# Online Examination Management — Lab Exam Practice

Java 17 target · Spring Boot 3.3.5 · MongoDB · Vue 3 · Axios

## Included logic
- CRUD for `exams` and `results` (create, list, find by ID, update, delete)
- Form-based Vue UI with field inputs, records table, edit and delete actions
- Scenario-specific report: **Students who failed** (`status equals FAIL`)
- MongoDB aggregation join using `$lookup`: `results.examId` matched to `exams.examId`

## Run
1. Start MongoDB locally (`mongodb://localhost:27017`).
2. In `backend`, run `mvn spring-boot:run`.
3. In a second terminal, enter `frontend`, run `npm install` and `npm run dev`.
4. Open the Vite URL, normally `http://localhost:5173`.

## API
- GET/POST `/api/exams`
- GET/PUT/DELETE `/api/exams/{id}`
- GET/POST `/api/results`
- GET/PUT/DELETE `/api/results/{id}`
- GET `/api/reports/special`
- GET `/api/reports/joined`

The relationship field `examId` must have the same value in both collections for the join to match. This is a lab practice project; adjust rules to the exact question statement.
