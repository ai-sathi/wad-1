package com.example.onlineexam.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="results")
public class Result {
@Id private String id;
private String resultId;
private String studentName;
private String examId;
private double marksObtained;
private String status;
public Result(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getResultId(){return resultId;} public void setResultId(String resultId){this.resultId=resultId;}
public String getStudentName(){return studentName;} public void setStudentName(String studentName){this.studentName=studentName;}
public String getExamId(){return examId;} public void setExamId(String examId){this.examId=examId;}
public double getMarksObtained(){return marksObtained;} public void setMarksObtained(double marksObtained){this.marksObtained=marksObtained;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
