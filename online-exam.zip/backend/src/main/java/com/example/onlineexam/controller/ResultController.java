package com.example.onlineexam.controller;
import com.example.onlineexam.model.Result; import com.example.onlineexam.repository.ResultRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/results") @CrossOrigin(origins="http://localhost:5173")
public class ResultController {
private final ResultRepository repo; public ResultController(ResultRepository repo){this.repo=repo;}
@GetMapping public List<Result> all(){return repo.findAll();}
@GetMapping("/{id}") public Result one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Result create(@RequestBody Result x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Result update(@PathVariable String id,@RequestBody Result x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
