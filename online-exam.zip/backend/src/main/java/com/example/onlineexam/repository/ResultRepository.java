package com.example.onlineexam.repository;
import com.example.onlineexam.model.Result;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ResultRepository extends MongoRepository<Result,String>{}
