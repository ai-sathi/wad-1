package com.example.flightbooking.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="flights")
public class Flight {
@Id private String id;
private String flightId;
private String airline;
private String source;
private String destination;
private int availableSeats;
private double price;
public Flight(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getFlightId(){return flightId;} public void setFlightId(String flightId){this.flightId=flightId;}
public String getAirline(){return airline;} public void setAirline(String airline){this.airline=airline;}
public String getSource(){return source;} public void setSource(String source){this.source=source;}
public String getDestination(){return destination;} public void setDestination(String destination){this.destination=destination;}
public int getAvailableSeats(){return availableSeats;} public void setAvailableSeats(int availableSeats){this.availableSeats=availableSeats;}
public double getPrice(){return price;} public void setPrice(double price){this.price=price;}
}
