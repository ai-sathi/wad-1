# Bus Ticket Reservation — Lab Exam Practice

Java 17 target · Spring Boot 3.3.5 · MongoDB · Vue 3 · Axios

## Included logic
- CRUD for `buses` and `tickets` (create, list, find by ID, update, delete)
- Form-based Vue UI with field inputs, records table, edit and delete actions
- Scenario-specific report: **Fully booked buses** (`availableSeats less than 0`)
- MongoDB aggregation join using `$lookup`: `tickets.busId` matched to `buses.busId`

## Run
1. Start MongoDB locally (`mongodb://localhost:27017`).
2. In `backend`, run `mvn spring-boot:run`.
3. In a second terminal, enter `frontend`, run `npm install` and `npm run dev`.
4. Open the Vite URL, normally `http://localhost:5173`.

## API
- GET/POST `/api/buses`
- GET/PUT/DELETE `/api/buses/{id}`
- GET/POST `/api/tickets`
- GET/PUT/DELETE `/api/tickets/{id}`
- GET `/api/reports/special`
- GET `/api/reports/joined`

The relationship field `busId` must have the same value in both collections for the join to match. This is a lab practice project; adjust rules to the exact question statement.
