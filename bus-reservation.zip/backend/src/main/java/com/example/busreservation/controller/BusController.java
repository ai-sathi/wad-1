package com.example.busreservation.controller;
import com.example.busreservation.model.Bus; import com.example.busreservation.repository.BusRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/buses") @CrossOrigin(origins="http://localhost:5173")
public class BusController {
private final BusRepository repo; public BusController(BusRepository repo){this.repo=repo;}
@GetMapping public List<Bus> all(){return repo.findAll();}
@GetMapping("/{id}") public Bus one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Bus create(@RequestBody Bus x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Bus update(@PathVariable String id,@RequestBody Bus x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
