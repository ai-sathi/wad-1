package com.example.busreservation.repository;
import com.example.busreservation.model.Bus;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface BusRepository extends MongoRepository<Bus,String>{}
