package com.example.busreservation.controller;
import com.example.busreservation.model.Ticket; import com.example.busreservation.repository.TicketRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/tickets") @CrossOrigin(origins="http://localhost:5173")
public class TicketController {
private final TicketRepository repo; public TicketController(TicketRepository repo){this.repo=repo;}
@GetMapping public List<Ticket> all(){return repo.findAll();}
@GetMapping("/{id}") public Ticket one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Ticket create(@RequestBody Ticket x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Ticket update(@PathVariable String id,@RequestBody Ticket x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
