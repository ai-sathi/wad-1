package com.example.busreservation.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="tickets")
public class Ticket {
@Id private String id;
private String ticketId;
private String passengerName;
private String busId;
private int seatsBooked;
private String travelDate;
private String status;
public Ticket(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getTicketId(){return ticketId;} public void setTicketId(String ticketId){this.ticketId=ticketId;}
public String getPassengerName(){return passengerName;} public void setPassengerName(String passengerName){this.passengerName=passengerName;}
public String getBusId(){return busId;} public void setBusId(String busId){this.busId=busId;}
public int getSeatsBooked(){return seatsBooked;} public void setSeatsBooked(int seatsBooked){this.seatsBooked=seatsBooked;}
public String getTravelDate(){return travelDate;} public void setTravelDate(String travelDate){this.travelDate=travelDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
