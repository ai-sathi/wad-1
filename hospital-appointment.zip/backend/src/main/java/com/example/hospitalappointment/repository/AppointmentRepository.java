package com.example.hospitalappointment.repository;
import com.example.hospitalappointment.model.Appointment;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface AppointmentRepository extends MongoRepository<Appointment,String>{}
