package com.example.hospitalappointment.controller;
import com.example.hospitalappointment.model.Appointment; import com.example.hospitalappointment.repository.AppointmentRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/appointments") @CrossOrigin(origins="http://localhost:5173")
public class AppointmentController {
private final AppointmentRepository repo; public AppointmentController(AppointmentRepository repo){this.repo=repo;}
@GetMapping public List<Appointment> all(){return repo.findAll();}
@GetMapping("/{id}") public Appointment one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Appointment create(@RequestBody Appointment x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Appointment update(@PathVariable String id,@RequestBody Appointment x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
