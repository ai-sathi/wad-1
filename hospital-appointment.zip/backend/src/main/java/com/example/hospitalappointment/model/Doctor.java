package com.example.hospitalappointment.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="doctors")
public class Doctor {
@Id private String id;
private String doctorId;
private String name;
private String specialty;
private double consultationFee;
private boolean available;
public Doctor(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getDoctorId(){return doctorId;} public void setDoctorId(String doctorId){this.doctorId=doctorId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getSpecialty(){return specialty;} public void setSpecialty(String specialty){this.specialty=specialty;}
public double getConsultationFee(){return consultationFee;} public void setConsultationFee(double consultationFee){this.consultationFee=consultationFee;}
public boolean getAvailable(){return available;} public void setAvailable(boolean available){this.available=available;}
}
