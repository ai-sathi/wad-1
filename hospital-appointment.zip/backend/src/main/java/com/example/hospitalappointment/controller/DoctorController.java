package com.example.hospitalappointment.controller;
import com.example.hospitalappointment.model.Doctor; import com.example.hospitalappointment.repository.DoctorRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/doctors") @CrossOrigin(origins="http://localhost:5173")
public class DoctorController {
private final DoctorRepository repo; public DoctorController(DoctorRepository repo){this.repo=repo;}
@GetMapping public List<Doctor> all(){return repo.findAll();}
@GetMapping("/{id}") public Doctor one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Doctor create(@RequestBody Doctor x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Doctor update(@PathVariable String id,@RequestBody Doctor x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
