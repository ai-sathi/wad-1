package com.example.warehouseorders.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="purchaseOrders")
public class PurchaseOrder {
@Id private String id;
private String orderId;
private String supplierId;
private String itemName;
private int quantity;
private String orderDate;
private String status;
public PurchaseOrder(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getOrderId(){return orderId;} public void setOrderId(String orderId){this.orderId=orderId;}
public String getSupplierId(){return supplierId;} public void setSupplierId(String supplierId){this.supplierId=supplierId;}
public String getItemName(){return itemName;} public void setItemName(String itemName){this.itemName=itemName;}
public int getQuantity(){return quantity;} public void setQuantity(int quantity){this.quantity=quantity;}
public String getOrderDate(){return orderDate;} public void setOrderDate(String orderDate){this.orderDate=orderDate;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
