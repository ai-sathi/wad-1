package com.example.warehouseorders.controller;
import com.example.warehouseorders.model.Supplier; import com.example.warehouseorders.repository.SupplierRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/suppliers") @CrossOrigin(origins="http://localhost:5173")
public class SupplierController {
private final SupplierRepository repo; public SupplierController(SupplierRepository repo){this.repo=repo;}
@GetMapping public List<Supplier> all(){return repo.findAll();}
@GetMapping("/{id}") public Supplier one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Supplier create(@RequestBody Supplier x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Supplier update(@PathVariable String id,@RequestBody Supplier x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
