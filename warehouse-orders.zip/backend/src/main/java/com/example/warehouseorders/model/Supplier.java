package com.example.warehouseorders.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="suppliers")
public class Supplier {
@Id private String id;
private String supplierId;
private String name;
private String phone;
private String email;
public Supplier(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getSupplierId(){return supplierId;} public void setSupplierId(String supplierId){this.supplierId=supplierId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getPhone(){return phone;} public void setPhone(String phone){this.phone=phone;}
public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
}
