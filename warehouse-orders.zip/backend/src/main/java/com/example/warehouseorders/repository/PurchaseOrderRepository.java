package com.example.warehouseorders.repository;
import com.example.warehouseorders.model.PurchaseOrder;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface PurchaseOrderRepository extends MongoRepository<PurchaseOrder,String>{}
