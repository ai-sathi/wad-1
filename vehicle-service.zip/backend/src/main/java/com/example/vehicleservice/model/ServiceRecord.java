package com.example.vehicleservice.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="serviceRecords")
public class ServiceRecord {
@Id private String id;
private String serviceId;
private String vehicleId;
private String serviceDate;
private String serviceType;
private double cost;
private String status;
public ServiceRecord(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getServiceId(){return serviceId;} public void setServiceId(String serviceId){this.serviceId=serviceId;}
public String getVehicleId(){return vehicleId;} public void setVehicleId(String vehicleId){this.vehicleId=vehicleId;}
public String getServiceDate(){return serviceDate;} public void setServiceDate(String serviceDate){this.serviceDate=serviceDate;}
public String getServiceType(){return serviceType;} public void setServiceType(String serviceType){this.serviceType=serviceType;}
public double getCost(){return cost;} public void setCost(double cost){this.cost=cost;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
