package com.example.vehicleservice.repository;
import com.example.vehicleservice.model.ServiceRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface ServiceRecordRepository extends MongoRepository<ServiceRecord,String>{}
