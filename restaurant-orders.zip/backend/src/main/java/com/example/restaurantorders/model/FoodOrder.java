package com.example.restaurantorders.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="foodOrders")
public class FoodOrder {
@Id private String id;
private String orderId;
private String customerName;
private String itemId;
private int quantity;
private double totalAmount;
private String status;
public FoodOrder(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getOrderId(){return orderId;} public void setOrderId(String orderId){this.orderId=orderId;}
public String getCustomerName(){return customerName;} public void setCustomerName(String customerName){this.customerName=customerName;}
public String getItemId(){return itemId;} public void setItemId(String itemId){this.itemId=itemId;}
public int getQuantity(){return quantity;} public void setQuantity(int quantity){this.quantity=quantity;}
public double getTotalAmount(){return totalAmount;} public void setTotalAmount(double totalAmount){this.totalAmount=totalAmount;}
public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
}
