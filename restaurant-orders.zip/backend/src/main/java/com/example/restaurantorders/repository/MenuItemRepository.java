package com.example.restaurantorders.repository;
import com.example.restaurantorders.model.MenuItem;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MenuItemRepository extends MongoRepository<MenuItem,String>{}
