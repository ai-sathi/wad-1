package com.example.restaurantorders.repository;
import com.example.restaurantorders.model.FoodOrder;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface FoodOrderRepository extends MongoRepository<FoodOrder,String>{}
