package com.example.restaurantorders.controller;
import com.example.restaurantorders.model.FoodOrder; import com.example.restaurantorders.repository.FoodOrderRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/foodOrders") @CrossOrigin(origins="http://localhost:5173")
public class FoodOrderController {
private final FoodOrderRepository repo; public FoodOrderController(FoodOrderRepository repo){this.repo=repo;}
@GetMapping public List<FoodOrder> all(){return repo.findAll();}
@GetMapping("/{id}") public FoodOrder one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public FoodOrder create(@RequestBody FoodOrder x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public FoodOrder update(@PathVariable String id,@RequestBody FoodOrder x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
