package com.example.restaurantorders.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="menuItems")
public class MenuItem {
@Id private String id;
private String itemId;
private String name;
private String category;
private double price;
private boolean available;
public MenuItem(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getItemId(){return itemId;} public void setItemId(String itemId){this.itemId=itemId;}
public String getName(){return name;} public void setName(String name){this.name=name;}
public String getCategory(){return category;} public void setCategory(String category){this.category=category;}
public double getPrice(){return price;} public void setPrice(double price){this.price=price;}
public boolean getAvailable(){return available;} public void setAvailable(boolean available){this.available=available;}
}
