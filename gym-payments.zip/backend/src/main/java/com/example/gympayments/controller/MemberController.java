package com.example.gympayments.controller;
import com.example.gympayments.model.Member; import com.example.gympayments.repository.MemberRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/members") @CrossOrigin(origins="http://localhost:5173")
public class MemberController {
private final MemberRepository repo; public MemberController(MemberRepository repo){this.repo=repo;}
@GetMapping public List<Member> all(){return repo.findAll();}
@GetMapping("/{id}") public Member one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Member create(@RequestBody Member x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Member update(@PathVariable String id,@RequestBody Member x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
