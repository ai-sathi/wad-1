package com.example.gympayments.controller;
import org.bson.Document; import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation; import org.springframework.data.mongodb.core.query.Criteria; import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.*; import java.util.List; import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
@RestController @RequestMapping("/api/reports") @CrossOrigin(origins="http://localhost:5173")
public class ReportsController {
private final MongoTemplate mongo; public ReportsController(MongoTemplate mongo){this.mongo=mongo;}
@GetMapping("/special") public List<Document> special(){return mongo.find(new Query(Criteria.where("status").is("DUE")),Document.class,"payments");}
@GetMapping("/joined") public List<Document> joined(){Aggregation a=newAggregation(lookup("members","memberId","memberId","relatedDetails"));return mongo.aggregate(a,"payments",Document.class).getMappedResults();}
}
