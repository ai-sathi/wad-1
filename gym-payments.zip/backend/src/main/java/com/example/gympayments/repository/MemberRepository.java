package com.example.gympayments.repository;
import com.example.gympayments.model.Member;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MemberRepository extends MongoRepository<Member,String>{}
