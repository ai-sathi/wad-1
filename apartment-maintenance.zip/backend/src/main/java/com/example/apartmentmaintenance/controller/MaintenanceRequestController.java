package com.example.apartmentmaintenance.controller;
import com.example.apartmentmaintenance.model.MaintenanceRequest; import com.example.apartmentmaintenance.repository.MaintenanceRequestRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/maintenanceRequests") @CrossOrigin(origins="http://localhost:5173")
public class MaintenanceRequestController {
private final MaintenanceRequestRepository repo; public MaintenanceRequestController(MaintenanceRequestRepository repo){this.repo=repo;}
@GetMapping public List<MaintenanceRequest> all(){return repo.findAll();}
@GetMapping("/{id}") public MaintenanceRequest one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public MaintenanceRequest create(@RequestBody MaintenanceRequest x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public MaintenanceRequest update(@PathVariable String id,@RequestBody MaintenanceRequest x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
