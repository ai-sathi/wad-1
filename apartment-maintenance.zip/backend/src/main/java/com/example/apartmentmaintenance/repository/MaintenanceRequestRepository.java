package com.example.apartmentmaintenance.repository;
import com.example.apartmentmaintenance.model.MaintenanceRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MaintenanceRequestRepository extends MongoRepository<MaintenanceRequest,String>{}
