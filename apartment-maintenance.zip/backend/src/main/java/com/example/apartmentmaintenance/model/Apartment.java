package com.example.apartmentmaintenance.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="apartments")
public class Apartment {
@Id private String id;
private String apartmentId;
private String unitNumber;
private String residentName;
private String building;
public Apartment(){}
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getApartmentId(){return apartmentId;} public void setApartmentId(String apartmentId){this.apartmentId=apartmentId;}
public String getUnitNumber(){return unitNumber;} public void setUnitNumber(String unitNumber){this.unitNumber=unitNumber;}
public String getResidentName(){return residentName;} public void setResidentName(String residentName){this.residentName=residentName;}
public String getBuilding(){return building;} public void setBuilding(String building){this.building=building;}
}
