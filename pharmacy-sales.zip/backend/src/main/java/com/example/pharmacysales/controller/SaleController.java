package com.example.pharmacysales.controller;
import com.example.pharmacysales.model.Sale; import com.example.pharmacysales.repository.SaleRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/sales") @CrossOrigin(origins="http://localhost:5173")
public class SaleController {
private final SaleRepository repo; public SaleController(SaleRepository repo){this.repo=repo;}
@GetMapping public List<Sale> all(){return repo.findAll();}
@GetMapping("/{id}") public Sale one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Sale create(@RequestBody Sale x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Sale update(@PathVariable String id,@RequestBody Sale x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
