package com.example.pharmacysales.repository;
import com.example.pharmacysales.model.Medicine;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface MedicineRepository extends MongoRepository<Medicine,String>{}
