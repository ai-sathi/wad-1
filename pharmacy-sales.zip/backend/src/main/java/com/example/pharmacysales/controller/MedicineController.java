package com.example.pharmacysales.controller;
import com.example.pharmacysales.model.Medicine; import com.example.pharmacysales.repository.MedicineRepository;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import org.springframework.web.server.ResponseStatusException; import java.util.List;
@RestController @RequestMapping("/api/medicines") @CrossOrigin(origins="http://localhost:5173")
public class MedicineController {
private final MedicineRepository repo; public MedicineController(MedicineRepository repo){this.repo=repo;}
@GetMapping public List<Medicine> all(){return repo.findAll();}
@GetMapping("/{id}") public Medicine one(@PathVariable String id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found"));}
@PostMapping public Medicine create(@RequestBody Medicine x){x.setId(null);return repo.save(x);}
@PutMapping("/{id}") public Medicine update(@PathVariable String id,@RequestBody Medicine x){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");x.setId(id);return repo.save(x);}
@DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable String id){if(!repo.existsById(id))throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Record not found");repo.deleteById(id);}
}
